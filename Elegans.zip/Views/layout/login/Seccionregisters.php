<div class="wrapper">
    <aside id="sidebar" class="js-sidebar">
        <!-- Content For Sidebar -->
        <div class="h-100">
            <div class="sidebar-logo">
                <a href="#"><img class="img-fluid" src="/Public/dist/img/Logo.png" alt="" style="width: 200px; height:200px;position: relative;    top: -60px;"></a>
            </div>
            <ul class="sidebar-nav">
                <li class="sidebar-header">
                    Elementos de Usuario
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link">
                        <i class="fa-solid fa-house"></i>
                        Inicio
                    </a>
                </li>




            </ul>
        </div>
    </aside>
    <div class="main">
        <nav class="navbar navbar-expand px-3 border-bottom">
            <button class="btn" id="sidebar-toggle" type="button">
                <span class="navbar-toggler-icon"></span>
            </button>

        </nav>
        <main class="content px-3 py-2">
            <div class="container mt-5">
                
            </div>
    </div>

    </main>
    <a href="#" class="theme-toggle">
        <i class="fa-regular fa-moon"></i>
        <i class="fa-regular fa-sun"></i>
    </a>
    <footer class="footer">
        <div class="container-fluid">
            <div class="row text-muted">
                <div class="col-6 text-start">
                    <p class="mb-0">
                        <a href="#" class="text-muted">
                            <strong>Elegans</strong>
                        </a>
                    </p>
                </div>
                <div class="col-6 text-end">
                    <ul class="list-inline">

                        <li class="list-inline-item">
                            <a href="#" class="text-muted" data-bs-toggle="modal" data-bs-target="#terminosCondicionesModal">Términos y Condiciones</a>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
    </footer>
</div>
</div>