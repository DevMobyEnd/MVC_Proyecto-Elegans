<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Acceso No Autorizado</title>
</head>
<body>
    <h1>Acceso No Autorizado</h1>
    <p>Lo sentimos, no tienes permiso para acceder a esta página.</p>
    <a href="/./Views/login.php">Volver al inicio</a>
</body>
</html>