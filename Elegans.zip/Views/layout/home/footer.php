<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-6 text-start">
                <p class="mb-0">
                    <a href="#" class="text-muted">
                        <strong>Elegans</strong>
                    </a>
                </p>
            </div>
            <div class="col-6 text-end">
                <ul class="list-inline">

                    <li class="list-inline-item">
                        <a href="#" class="text-muted" data-bs-toggle="modal" data-bs-target="#terminosCondicionesModal">Términos y Condiciones</a>
                    </li>

                </ul>
            </div>
        </div>
    </div>
</footer>