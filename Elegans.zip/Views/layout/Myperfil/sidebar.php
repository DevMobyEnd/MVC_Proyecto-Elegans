<div class="h-100">
    <div class="sidebar-logo" style="padding: 10px 0; text-align: center;">
        <a href="#"><img class="img-fluid" src="/Public/dist/img/Logo.png" alt="" style="width: 200px; height: 200px; margin-top: -30px; margin-left: -25px;"></a>
    </div>
    <ul class="sidebar-nav">
        <li class="sidebar-header">
            Elementos de Usuario
        </li>
        <li class="sidebar-item">
            <a href="index.php" class="sidebar-link">
                <i class="fas fa-home"></i>
                Inicio
            </a>
        </li>
        <li class="sidebar-item">
            <a href="SeccionChatDialogos.html" class="sidebar-link">
                <i class="fa-solid fa-comments"></i>
                Canal de Dialogo
            </a>
        </li>
        <!-- Agrega más elementos del menú lateral aquí -->
    </ul>
</div>