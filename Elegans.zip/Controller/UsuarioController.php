<?php
require_once '../Config/global.php';
require_once '../Models/UsuarioModel.php';

class UsuarioController
{
    private $modelo;

    public function __construct()
    {
        $this->modelo = new UsuarioModel();
    }

    public function verificarEmail($email)
    {
        $usuario = $this->modelo->obtenerUsuarioPorEmail($email);
        if ($usuario) {
            return ['success' => true, 'message' => 'Email verificado'];
        } else {
            return ['success' => false, 'message' => 'Email no encontrado'];
        }
    }

    public function obtenerDatosUsuarioActual($usuarioId) {
        $usuario = $this->modelo->obtenerUsuarioPorId($usuarioId);
        if ($usuario) {
            return [
                'id' => $usuario['id'],
                'nombres' => $usuario['nombres'],
                'apellidos' => $usuario['apellidos'],
                'email' => $usuario['Gmail'],
                'foto_perfil' => $usuario['foto_perfil'],
                'apodo' => $usuario['Apodo']
            ];
        }
        return null;
    }

    public function login($email, $password)
    {
        $usuario = $this->modelo->obtenerUsuarioPorEmail($email);
        if ($usuario) {
            // Verifica si las claves existen antes de acceder a ellas
            $loginAttempts = isset($usuario['login_attempts']) ? $usuario['login_attempts'] : 0;
            $lastLoginAttempt = isset($usuario['last_login_attempt']) ? strtotime($usuario['last_login_attempt']) : 0;

            if ($loginAttempts >= 3 && time() - $lastLoginAttempt < 900) {
                return ['success' => false, 'message' => 'Cuenta bloqueada. Intente de nuevo en 15 minutos.'];
            }

            if (password_verify($password, $usuario['password'])) {
                $this->modelo->resetearIntentos($usuario['id']);
                $token = $this->modelo->crearToken($usuario['id'], 'login');

                // Establecer variables de sesión
                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['apodo'] = $usuario['Apodo'] ?? '';  // Use null coalescing operator
                $_SESSION['foto_perfil'] = $usuario['foto_perfil'] ?? '';
                $_SESSION['nombre_completo'] = $usuario['nombres'] . ' ' . $usuario['apellidos'];
                // Depuración
                error_log("Sesión iniciada: " . print_r($_SESSION, true));

                return ['success' => true, 'message' => 'Login exitoso', 'token' => $token];
            } else {
                $this->modelo->incrementarIntentos($usuario['id']);
                return ['success' => false, 'message' => 'Credenciales incorrectas'];
            }
        } else {
            return ['success' => false, 'message' => 'Usuario no encontrado'];
        }
    }

    public function iniciarSesionConToken($token)
    {
        $userId = $this->modelo->verificarToken($token, 'login');
        if ($userId) {
            // Iniciar sesión
            $_SESSION['usuario_id'] = $userId;
            return ['success' => true, 'message' => 'Sesión iniciada con token'];
        }
        return ['success' => false, 'message' => 'Token inválido o expirado'];
    }

    public function solicitarRecuperacionContrasena($email)
    {
        $usuario = $this->modelo->obtenerUsuarioPorEmail($email);
        if ($usuario) {
            $token = $this->modelo->crearToken($usuario['id'], 'password_reset');
            // Aquí deberías enviar un email con el link de recuperación
            // que incluya el token
            return ['success' => true, 'message' => 'Se ha enviado un email de recuperación'];
        }
        return ['success' => false, 'message' => 'Email no encontrado'];
    }
}
